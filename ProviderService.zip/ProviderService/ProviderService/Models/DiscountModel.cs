﻿namespace ProviderService.Models
{
    public class DiscountModel
    {
        public double CustomerRating { get; set; }
        public double AmountToDiscount { get; set; }
    }

}
