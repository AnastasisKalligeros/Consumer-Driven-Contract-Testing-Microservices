﻿namespace ProviderService.Models
{
    public class DiscountResponse
    {
        public double CustomerRating { get; set; }
        public double AmountToDiscount { get; set; }
    }

}
